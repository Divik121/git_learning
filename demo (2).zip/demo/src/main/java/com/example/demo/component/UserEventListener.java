package com.example.demo.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Company;
import com.example.demo.model.UserChangeEvent;
import com.example.demo.repo.UserRepository;

@Component
public class UserEventListener {

    private final SimpMessagingTemplate messagingTemplate;
    private final UserRepository userRepository;

    @Autowired
    public UserEventListener(SimpMessagingTemplate messagingTemplate, UserRepository userRepository) {
        this.messagingTemplate = messagingTemplate;
        this.userRepository = userRepository;
    }

    @EventListener
    public void handleUserChangeEvent(UserChangeEvent event) {
        Company user = userRepository.findById(event.getUserId()).orElse(null);
        if (user != null) {
            messagingTemplate.convertAndSend("/topic/user-changes", user);
        }
    }

}
