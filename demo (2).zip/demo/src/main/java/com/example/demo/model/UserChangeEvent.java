package com.example.demo.model;

public class UserChangeEvent {

    private int userId;

    public UserChangeEvent(int userId) {
        this.userId = userId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}