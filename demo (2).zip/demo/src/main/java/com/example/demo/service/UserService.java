package com.example.demo.service;

import java.util.List;

//import javax.persistence.Cacheable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Company;
import com.example.demo.model.UserChangeEvent;
import com.example.demo.repo.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final ApplicationEventPublisher eventPublisher;

    @Autowired
    public UserService(UserRepository userRepository, ApplicationEventPublisher eventPublisher) {
        this.userRepository = userRepository;
        this.eventPublisher = eventPublisher;
    }
    
    @Cacheable("myCache")
    public List<Company> getMyEntities() {
        return userRepository.findAll();
    }

    public void saveUser(Company user) {
        userRepository.save(user);
        eventPublisher.publishEvent(new UserChangeEvent(user.getId()));
    }
    
    public Company saveUser1(Company user) {
        userRepository.save(user);
        eventPublisher.publishEvent(new UserChangeEvent(user.getId()));
		return user;
    }
    
    @CacheEvict("myCache")
    public void save(Company user) {
        userRepository.save(user);
    }

}